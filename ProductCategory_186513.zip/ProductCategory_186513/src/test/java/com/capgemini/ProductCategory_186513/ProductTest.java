package com.capgemini.ProductCategory_186513;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.productmgmt.dao.IProductDao;
import com.capgemini.productmgmt.dao.ProductDao;
import com.capgemini.productmgmt.exception.ProductException;

public class ProductTest {
/**
 * this is the class for testing the methods implemented in dao layer
 * @throws Exception
 */
	IProductDao dao=null;
	@Before
	public void setUp() throws Exception {
		dao=new ProductDao();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}
	

	@Test
	public void testUpdateProducts() {
		try {
			int value=dao.UpdateProducts("soap", 2);
			assertNotNull(value);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	@Test
	public void testNegativeUpdateProducts() {
		try {
			int value=dao.UpdateProducts("soap", 2);
			assertNull(value);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetProductDetails() {
		try {
			Map<String, Integer> map11=dao.getProductDetails();
			assertTrue(map11.size()==7);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void testNegativeGetProductDetails() {
		try {
			Map<String, Integer> map11=dao.getProductDetails();
			assertFalse(map11.size()==7);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetDetails() {
		try {
			Map<String, String> map22=dao.getDetails();
			assertNotNull(map22);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testNegativeGetDetails() {
		try {
			Map<String, String> map22=dao.getDetails();
			assertNull(map22);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
