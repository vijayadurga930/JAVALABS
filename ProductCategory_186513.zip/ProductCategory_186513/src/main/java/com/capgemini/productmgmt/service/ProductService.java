package com.capgemini.productmgmt.service;

import java.util.Iterator;
import java.util.Map;

import com.capgemini.productmgmt.dao.IProductDao;
import com.capgemini.productmgmt.dao.ProductDao;
import com.capgemini.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
	/**
	 * this is the implementation of service layer
	 * here we are implementing the methods written in service interface
	 */
IProductDao dao=new ProductDao();
	public int UpdateProducts(String Category, int hike) throws ProductException {
		// TODO Auto-generated method stub
		return dao.UpdateProducts(Category, hike);
	}

	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return dao.getProductDetails();
	}

	public boolean ValidateHike(int hike) throws ProductException {
		// TODO Auto-generated method stub
		boolean status=false;
		if(hike>0)
		{
			status=true;
		}
		else {
			throw new ProductException("hike rate should be greater than zero");
		}
		return status;
	}

	public boolean getVerifyProduct(String category) throws ProductException {
		// TODO Auto-generated method stub
		Map<String, String> map1=dao.getDetails();
		boolean status=false;
		Iterator<String> iterator1=map1.keySet().iterator();
		while(iterator1.hasNext())
		{
			String name1=iterator1.next();
			String category1=map1.get(name1);
			if(category1.equals(category))
			{
				status=true;
			}
			
		}
		if(status==false)
		{
			throw new ProductException("entered category is not in the list" );
		}
		return status;
	}

}
