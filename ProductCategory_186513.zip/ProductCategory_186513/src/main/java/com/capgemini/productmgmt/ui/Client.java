package com.capgemini.productmgmt.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.productmgmt.exception.ProductException;
import com.capgemini.productmgmt.service.IProductService;
import com.capgemini.productmgmt.service.ProductService;
/**
 * 
 * @author pteegala
 * @presentation layer
 *
 */

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**
		 * here we are displaying the menu and taking the details from the user
		 */
		Scanner scanner = new Scanner(System.in);
		IProductService service = new ProductService();
		boolean continuevalue = false;
		System.out.println("enter the required option from the list");
		System.out.println("our menu is as follows:");
		boolean val = false;
		do {

			System.out.println("1)update Product price\n2)Display Product List\n3)Exit");
			try {
				System.out.println("enter the option required");
				int option = scanner.nextInt();
				val = true;
				switch (option) {
				case 1: {
					String category = null;
					do {
						try {
							System.out.println("enter product name");
							category = scanner.next();
							service.getVerifyProduct(category);
							continuevalue = true;
						} catch (ProductException e) {
							// TODO: handle exception
							continuevalue = false;
							System.err.println(e.getMessage());

						}
					} while (!continuevalue);

					int hike = 0;
					do {
						try {
							System.out.println("enter hike rate");
							hike = scanner.nextInt();
							service.ValidateHike(hike);
							continuevalue = true;
						} catch (ProductException e) {
							// TODO Auto-generated catch block
							continuevalue = false;
							System.err.println(e.getMessage());
							scanner.nextLine();
						}
					} while (!continuevalue);
					System.out.println("the details you have entered are updated succesfully");
					try {
						service.UpdateProducts(category, hike);
					} catch (ProductException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					try {
						System.out.println(service.getProductDetails());
					} catch (ProductException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				}
					break;
				case 2: {
					System.out.println("showing the product list");
					try {
						System.out.println(service.getProductDetails());
					} catch (ProductException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
					break;

				case 3: {
					System.out.println("the system  gettting exited");
					System.exit(0);

				}
					break;

				default: {
					System.err.println("entered option should be between 1-3");
					val = false;
					scanner.nextLine();
				}
					break;
				}

			do {

				scanner = new Scanner(System.in);

				System.out.println("do you want to continue again [yes/no]");
				String continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continuevalue = true;
					val = false;
					break;

				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continuevalue = true;
					val = true;
					break;
				} else {
					System.out.println("enter yes or no");
					continuevalue = false;
					continue;
				}
			} while (!continuevalue);
			}
			 catch (InputMismatchException e) {
				// TODO: handle exception
				val = false;
				System.err.println("option must be in digit format");
				scanner.nextLine();
			}
		} while (!val);
	}

}
