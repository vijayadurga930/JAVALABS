package com.capgemini.productmgmt.exception;

public class ProductException extends Exception{
/**
 * this is the exception class we are handling exceptions here
 * @param message
 */
	public ProductException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
