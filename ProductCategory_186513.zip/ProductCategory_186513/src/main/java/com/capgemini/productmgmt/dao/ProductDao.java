package com.capgemini.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.productmgmt.beans.Product;
import com.capgemini.productmgmt.exception.ProductException;

public class ProductDao implements IProductDao {
	/**
	 * this is dao layer implementation all the methods are get implemented
	 * we are creating methods to update and displaying details
	 */
 static Map<String, String> productDetails=null;
 static Map<String, Integer> salesDetails=null;
 Product product=new Product();
 static {
	 productDetails=new HashMap<String, String>();
	 productDetails.put("lux", "soap");
	 productDetails.put("colgate", "paste");
	 productDetails.put("pears", "soap");
	 productDetails.put("sony", "electronics");
	 productDetails.put("samsung", "electronics");
	 productDetails.put("facepack", "cosmatics");
	 productDetails.put("facecream", "cosmatics");
	 
 }
 static {
	 salesDetails=new HashMap<String, Integer>();
	 salesDetails.put("lux", 100);
	 salesDetails.put("colgate", 50);
	 salesDetails.put("pears", 70);
	 salesDetails.put("sony", 10000);
	 salesDetails.put("samsung", 23000);
	 salesDetails.put("facepack", 100);
	 salesDetails.put("facecream", 60);
 }

	public int UpdateProducts(String Category, int hike) throws ProductException {
		// TODO Auto-generated method stub
		int updatedhike=0;
		Iterator<String> iterator1=productDetails.keySet().iterator();
		while(iterator1.hasNext())
		{
			String name1=iterator1.next();
			String Category1=productDetails.get(name1);
			if(Category1.equals(Category))
			{
				Iterator<String> iterator2=salesDetails.keySet().iterator();
				while(iterator2.hasNext())
				{
					String name2=iterator2.next();
					int rate=salesDetails.get(name2);
					if(name1.equals(name2))
					{
					 updatedhike=((rate*hike)/100)+rate;
					 salesDetails.put(name1, updatedhike);
					}
					
				}
				
			}
			
		}
		return updatedhike;
	}

	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return salesDetails;
	}

	public Map<String, String> getDetails() throws ProductException {
		// TODO Auto-generated method stub
		return productDetails;
	}

}
