package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductService {
	/**
	 * this is service layer interface we are giving methods to validate conditions
	 * @param Category
	 * @param hike
	 * @return
	 * @throws ProductException
	 */
public int UpdateProducts(String Category,int hike) throws ProductException;
public Map<String, Integer> getProductDetails() throws ProductException;
public boolean ValidateHike(int hike) throws ProductException;
public boolean getVerifyProduct(String category) throws ProductException;
}
