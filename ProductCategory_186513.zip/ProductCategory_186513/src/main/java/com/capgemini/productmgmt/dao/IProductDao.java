package com.capgemini.productmgmt.dao;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductDao {
	/**
	 * this is dao interface where the methods are just defined
	 * @param Category
	 * @param hike
	 * @return
	 * @throws ProductException
	 */
	public int UpdateProducts(String Category,int hike) throws ProductException;
	public Map<String, Integer> getProductDetails() throws ProductException;
	public Map<String, String> getDetails() throws ProductException;
}
