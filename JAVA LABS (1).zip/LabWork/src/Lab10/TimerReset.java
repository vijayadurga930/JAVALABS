package Lab10;
/*
 * Exercise 2: Write a thread program to display 
 * timer where timer will get refresh after every 10seconds.( Use Runnable implementation )
 */
import java.util.TimerTask;

public class TimerReset extends TimerTask implements Runnable {
	static int counter = 0;

	public static void main(String[] args) {
		
	}

	@Override
	public void run() {

		if (counter > 10) {
			counter = 0;
			System.out.println("Timer Refereshed..!!");
		} else {
			System.out.println("Timer : " + counter);
			counter++;
		}
	}

}
