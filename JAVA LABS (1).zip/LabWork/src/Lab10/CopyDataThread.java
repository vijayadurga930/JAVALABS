package Lab10;
/*
 * Exercise 1: Write a program to do the following operations using Thread:
 * Create an user defined Thread class called as �CopyDataThread .java� .
 * This class will be designed to copy the content from one file �source.txt � to another file �target.txt� and after every 10 characters copied, �10 characters are copied� message will be shown to user.(Keep delay of 5 seconds after every 10 characters read.)
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class CopyDataThread extends TimerTask {
	static int letter = 0;
	static int i = 0;
	private String source;
	private String target;
	static FileInputStream fin = null;
	static FileOutputStream fout = null;

	
	public CopyDataThread() {
		super();
		}
	


	public CopyDataThread(String source, String target) {
		super();
		this.source = source;
		this.target = target;
	}



	@Override
	public void run() {
		
		try {
			fin = new FileInputStream(source);
			fout = new FileOutputStream(target);
			while (i != -1) {
				try {
					i = fin.read();
					fout.write(i);
					
					letter++;
					if (letter == 10) {
						letter = 0;
						Thread.sleep(5000);
						/*Timer timer = new Timer("MyTimer");
						timer.scheduleAtFixedRate(new CopyDataThread(), 30, 3000);
					*/}
					System.out.print((char) i);
				
				} catch (IOException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				
	}
		}catch (IOException e) {
			e.printStackTrace();
		}
		

	}
	}



