package Lab10;
/*Exercise 1:
 * Create another class �FileProgram.java� which will create 
 * above thread. Pass required File Stream classes to CopyDataThread constructor and implement the above functionality.
 */
public class FileProgram {

	public static void main(String[] args) {
		String source="C:\\AmberSpace\\LabWork\\Sample.txt";
		String target="C:\\AmberSpace\\LabWork\\Sample2.txt";
		CopyDataThread copy=new CopyDataThread(source,target);
		copy.run();

	}

}
