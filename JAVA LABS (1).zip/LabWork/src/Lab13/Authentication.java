package Lab13;

/*
 * Exercise 3: Write a method that uses lambda expression to accept username and password and
return true or false. (Hint: Use any custom values for username and password for authentication)
 */
import java.util.Scanner;

public class Authentication {

	public static void main(String[] args) {

		Auth authenticate = (username, password) -> {
			if (username.equals("Amber") && password.equals("1234"))
				return "Authenticated";
			else
				return "Invalid credentials";
		};

		System.out.println("Enter \n Username:");
		Scanner scanner = new Scanner(System.in);
		String user = scanner.next();
		System.out.println("Password:");
		String pass = scanner.next();

		System.out.println(authenticate.auth(user, pass));
	}

}
