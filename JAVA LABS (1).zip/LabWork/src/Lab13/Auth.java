package Lab13;

public interface Auth {
	public String auth(String Username, String password);
}
