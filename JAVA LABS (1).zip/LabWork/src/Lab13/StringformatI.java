package Lab13;

public interface StringformatI {

	
		public void change(String s);
	
}
