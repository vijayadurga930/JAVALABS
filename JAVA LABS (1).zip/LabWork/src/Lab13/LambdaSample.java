package Lab13;

public interface LambdaSample {
    public int calculate(int x,int y);
}
