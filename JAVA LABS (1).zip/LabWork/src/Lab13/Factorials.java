package Lab13;

/*
 * Exercise 5: Write a method to calculate factorial of a number. Test this method using method
reference feature.
 */
import java.util.function.Function;

interface Fact {
	int calculateFactorial(int n);
}

public class Factorials implements Fact {

	public int calculateFactorial(int n) {
		int fact = 1;

		for (int i = n; i > 0; i--)
			fact = fact * i;

		return fact;
	}

	public static void main(String[] args) {
		Factorials fact = new Factorials();
		System.out.println("Factorial");
		Function<Integer, Integer> func = fact::calculateFactorial;
		System.out.println("Factorial of 5 is = " + func.apply(5));

	}

}
