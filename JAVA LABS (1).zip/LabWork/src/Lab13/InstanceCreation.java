package Lab13;

/*
 * Exercise 4: Write a class with main method to demonstrate instance creation using method
reference.
 */
import java.util.function.BiConsumer;

public class InstanceCreation {

	public static void main(String[] args) {

		BiConsumer<Integer, Integer> biconsumer = Sample::new;
		biconsumer.accept(5, 10);

	}

}

class Sample {
	Sample() {
		System.out.println("This is Sample Class. Called from class instance");
	}

	Sample(int a, int b) {
		System.out.println("Method Reference : 5+10=" + (a + b));
	}
}
