package Lab13;

/*
 * Exercise 1: Write a lambda expression which accepts x and y numbers and return xy.
 */
public class LambdaExpression {
	public static void main(String[] args) {

		LambdaSample sample = (x, y) -> {
			return (int) Math.pow(x, y);
		};

		System.out.println(sample.calculate(2, 2));

	}
}
