package Lab13;

/*
 * Exercise 2: Write a method that uses lambda expression to format a given string, where a space
is inserted between each character of string. For ex., if input is �CG�, then expected output is �C
G�.
 */
import java.util.Scanner;

public class StringFormat {

	public static void main(String[] args) {

		StringformatI changemain = (string) -> {
			String s = "";

			for (int i = 0; i < string.length(); i++)
				s = s + string.charAt(i) + " ";
			System.out.println("String is :" + s);
		};

		System.out.println("Enter String");
		Scanner scanner = new Scanner(System.in);
		String string = scanner.next();

		changemain.change(string);

	}

}
