package com.cg.eis.exception;

import java.util.Scanner;

public class EmployeeDetails {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Your Salary :");
		int salary = scanner.nextInt();
		
		try {
		if(salary<3000)
			throw new EmployeeException();
		else
			System.out.println("Salary is Validated");
	}
	 	catch(EmployeeException exc)
	 	{
	 		}
	}
}
		
