package Lab5;
/*Exercise 2: The Fibonacci sequence is defined by the following rule. The first 2 values in the sequence are 1, 1. Every subsequent value is 
 * the sum of the 2 values preceding it. Write a Java program that uses both recursive and nonrecursive functions to print the nth value of the Fibonacci sequence?
 * 
 */
import java.util.Scanner;

public class FibonacciSeries {
	
	void NonRecursive(int number)
	{
		int f1=1,f0=0,sum,temp=0;
		int i=2;
		System.out.print(f0+" "+f1);
		
		while(i<number)
		{
			sum=f0+f1;
			System.out.print(" "+sum);
			f0=f1;
			f1=sum;
			i++;
		}
	}
	
	void Recursive(int number,int fib0,int fib1) {
		
	     if(number>0) {	
		number--;
		System.out.print(" "+fib0);
		Recursive(number,fib1,fib1+fib0);
	     }
	}
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Number");
		int num=scanner.nextInt();
		
		
		FibonacciSeries fb=new FibonacciSeries();
		System.out.println("Non Recursive :");
		fb.NonRecursive(num);
		System.out.println("\n Recursive :");
		fb.Recursive(num,0,1);
		
		
	}

}
