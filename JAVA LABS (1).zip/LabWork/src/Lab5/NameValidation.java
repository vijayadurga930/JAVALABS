package Lab5;
/*
 * Exercise 4: Write a Java Program to validate the full name of an employee. Create 
 * and throw a user defined exception if firstName and lastName is blank.
 */
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NameValidation {
	
	static Pattern nameptn=Pattern.compile("[A-Za-z]*");
	
	static void CheckName(String name) throws NotValidName {
		
		Matcher match=nameptn.matcher(name);
		
		if(match.matches())
			System.out.println("Name is Validated");
		else
			System.out.println("Not a Valid Name");
	}
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Your Full Name");
		String name;
		
		try {
			
			System.out.println("First Name: ");
			String firstname=scanner.nextLine();
			System.out.println("Last Name: ");
			String lastname=scanner.nextLine();
			
			if(firstname.isEmpty()|| lastname.isEmpty())
				throw new NotValidName();
			
			else {
				name=firstname+lastname;
				System.out.println(name);
				CheckName(name);
			     }
			
		   }
		catch (NotValidName e) {			
			System.out.println("Name Cannot be blank");	
		}
	}

}
class NotValidName extends Exception{
	
	public NotValidName() {
		
	}
}


