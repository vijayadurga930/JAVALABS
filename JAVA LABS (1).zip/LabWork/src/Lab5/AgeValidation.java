package Lab5;
/*
 * Exercise 5: Validate the age of a person and display proper message 
 * by using user defined exception. Age of a person should be above 15.
 */
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AgeValidation {
	static Pattern nameptn=Pattern.compile("[0-9]*");
	static void CheckAge(String age)  {
		
		Matcher match=nameptn.matcher(age);
		
		if(match.matches())
			System.out.println("Age is Validated");
		else
			System.out.println("Not a Valid Age");
	}
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Your Age");
		String age;
		
		
		
		try {
			
			   age=scanner.nextLine();
			   int a=Integer.parseInt(age);
			
			if(a<=15)
				throw new NotValidAge();
			
			else {
				CheckAge(age);
			     }
			
		   }
		catch (NotValidAge e) {			
			System.out.println("You should be above 15 years");	
		}
		catch(NumberFormatException e) {
			System.out.println("Enter Numbers Only");
		}
		
	}

}
class NotValidAge extends Exception{
	
	public NotValidAge() {
		
	}
}


