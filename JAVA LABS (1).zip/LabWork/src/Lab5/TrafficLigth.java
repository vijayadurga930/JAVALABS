package Lab5;
/*
 * Exercise 1: Write a java program that simulates a traffic light. The program lets the user select one of three lights: red
 * , yellow, or green with radio buttons. On entering the choice, an appropriate message
 */
import java.util.Scanner;

public class TrafficLigth {

	public static void main(String[] args) {

		Scanner scanner=new Scanner(System.in);
		
		
		while(true)
		{	
			System.out.println("Enter Your Choice : \n 1.Red \n 2.Yellow \n 3.Green");
			String string=scanner.nextLine();
		switch(string)
		{
		case "Red" : System.out.println("Please Stop!!");
		 			break;
		case "Yellow": System.out.println("Please Wait and Look");
					break;
		case "Green" :System.out.println("You can go...!!");
		 System.exit(0);
		 break;
		 default:    System.out.println("Invalid input");
		 
		}
		}

	}

}
