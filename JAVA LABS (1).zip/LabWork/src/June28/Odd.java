package June28;

import java.util.Scanner;

public class Odd {
	int check(int num)
	{   
		 int rem,count=0;
            while(num>0)
			{
			rem=num%10;
			
			if(rem%3==0)
				count++;
			
			num=num/10;
				
		     }
		return count;
	}
	
	
	
	public static void main(String args[]) {
		int num,result;
		
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter a number ");
		num=scanner.nextInt();
		
		Odd obj=new Odd();
		result=obj.check(num);
		
		System.out.println(" numbers divisible by 3 are : "+result);
		
	}

}


