package June28;

import java.util.Scanner;

public class ArmstrongNumber {
	int checkArray(int array[]) {
		//For checking the armstrong number
	int number,copy;
	int rem1,count=0;
	
	for (int i = 0; i < array.length; i++) {
		int result = 0;
		int total = 0;
		number = array[i];
		copy=array[i];
		
		
		
		/*while (number > 0) {
			rem = number % 10;
			result = result+(rem*rem*rem);
			number = number / 10;
		}*/
		while(copy>0) // Counting the Digits
		{
			copy /=10;
			total++;
		}
		while (number > 0) { // Performing the Operation of Armstrong
			int rem=1;
			
			rem1 = number % 10;
			
			for(int j=0;j<total;j++)
				rem=rem*rem1;   
			
			result=result+rem;			
			number = number / 10;
		
			
		}
		if(result==array[i] ) 
			 count++;
		
	}
	

	return count;
}

	public static void main(String args[]) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter total number");
		int no = scanner.nextInt();

		int array[] = new int[no];

		System.out.println("Enter " + no + " Numbers");

		for (int i = 0; i < no; i++)
			array[i] = scanner.nextInt();

		ArmstrongNumber obj = new ArmstrongNumber();
		int arr = obj.checkArray(array);
		System.out.println("There are  " + arr + " Armstrong Numbers");

	}		
	
}
