package June28;

import java.util.Scanner;

public class ReverseNumber {

	int[] reverseArray(int array[]) {
		int number;
		int rem;
		for (int i = 0; i < array.length; i++) {
			number = array[i];
			int reverse = 0;
			while (number > 0) {
				rem = number % 10;
				reverse = reverse * 10 + rem;
				number = number / 10;

			}
			array[i] = reverse;

		}

		return array;
	}

	public static void main(String args[]) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter total number");
		int no = scanner.nextInt();
		
		int array[] = new int[no];
		
		System.out.println("Enter " + no + " Numbers");
		
		for (int i = 0; i < no; i++)
			array[i] = scanner.nextInt();

		ReverseNumber obj = new ReverseNumber();
		int arr[] = obj.reverseArray(array);
		System.out.println("number in Reverse are : ");
		
		for (int i = 0; i < no; i++)
			System.out.println(arr[i]);

	}

}
