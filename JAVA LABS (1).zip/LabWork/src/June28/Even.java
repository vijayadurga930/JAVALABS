package June28;

import java.util.Scanner;

public class Even {

	int check(int num)
	{   
		 int a,count=0;
		while(num>0)
		{
			a=num%10;
			
			if(a%2==0)
				count++;
			
			num=num/10;
				
		}
		return count;
	}
	
	
	
	public static void main(String args[]) {
		int num,result;
		
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter a number ");
		num=scanner.nextInt();
		
		Even obj=new Even();
		result=obj.check(num);
		
		System.out.println("Even numbers are : "+result);
		
	}

}
