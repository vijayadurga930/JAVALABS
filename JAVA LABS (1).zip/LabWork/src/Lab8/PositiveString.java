package Lab8;
/*
 * Exercise 5: Create a method that accepts a String and checks if it is a positive string. A string is considered a positive string, if on moving from left to right each character in the String comes after the previous characters in the Alphabetical order. For Example: 
 * ANT is a positive String (Since T comes after N and N comes after A). The method should return true if the entered string is positive.
 */
import java.util.Arrays;
import java.util.Scanner;

public class PositiveString {
	void matchString(String string) {
		int flag = 1;
		char[] compare = string.toCharArray();
		char[] chararr = string.toCharArray();
				
		Arrays.sort(chararr);
		System.out.println(chararr);
		String sample=new String(chararr);
				
		if (string.equals(sample))
			flag = 0;
				
		
		if (flag == 0)
			System.out.println("Given String is Positive String");
		else
			System.out.println("Given String is Not a Positive String");

	}

	public static void main(String[] args) {
		System.out.println("Enter Positive String");
		Scanner scanner = new Scanner(System.in);
		String string = scanner.nextLine();
		PositiveString ps = new PositiveString();

		ps.matchString(string);

	}
}
