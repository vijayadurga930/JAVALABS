package Lab8;
/*
 * Exercise 6: Create a method to accept date and print the duration in days, months and years with regards to current system date.
 */
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DateDiff {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Date in dd");
		int dd=scanner.nextInt();
		System.out.println("Enter Month in MM");
		int mm=scanner.nextInt();
		System.out.println("Enter Year in YYYY");
		int yyyy=scanner.nextInt();
		
	
		LocalDate date1=LocalDate.of(yyyy,mm,dd);		
		
		LocalDate localdate=LocalDate.now();
		Period diff=Period.between(date1, localdate);
		System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", 
                diff.getYears(), diff.getMonths(), diff.getDays());
}
		
		
	}


