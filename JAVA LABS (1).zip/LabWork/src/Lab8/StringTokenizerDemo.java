package Lab8;
/*
 * Exercise 1: Write a Java program that reads a line 
 * of integers and then displays each integer and the sum of all integers. (Use StringTokenizer class)?
 */
import java.util.Scanner;
import java.util.StringTokenizer;

public class StringTokenizerDemo {

	public static void main(String[] args) {
		System.out.println("Enter integers");
		Scanner scanner=new Scanner(System.in);
		String integers=scanner.nextLine();
		int sum=0,n;
		String temp;
		
		StringTokenizer st=new StringTokenizer(integers);
		while(st.hasMoreElements()) {
		     temp=st.nextToken();
		    n=Integer.parseInt(temp);
		    System.out.println(n);
		    sum=sum+n;
		}
		    System.out.println("Sum is :"+sum);
		
	}

}
