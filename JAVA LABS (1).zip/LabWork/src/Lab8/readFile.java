package Lab8;
/*
 * Exercise 4: Write a Java program that reads on file name from the user, 
 * then displays information about whether the file exists, whether the file is readable, whether the file is writable, the type of file and the length of the file in bytes?
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class readFile {

	public static void main(String[] args) {
		FileInputStream fin = null;
		FileOutputStream fout = null;
		int i = 0;
		int line = 1;

		try {
			fin = new FileInputStream("src/Lab8/StringTokenizerDemo.java");
			fout = new FileOutputStream("src/Lab8/NewFile.doc");
			System.out.print(line + " :");

			while (i != -1) {

				i = fin.read();
				fout.write(i);
				System.out.print((char) i);

				if (i == '\n') {
					line++;
					System.out.print(line + " :");

				}

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
