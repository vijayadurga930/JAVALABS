package Lab8;
/*
 * Exercise 7: You are asked to create an application for registering the details of jobseeker. The requirement is:
Username should always end with _job and there should be at least minimum of 8 characters to the left of _job. Write 
a function to validate the same. Return true in case the validation is passed. In case of validation failure return false.
 */
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JobSeeker {
	static Pattern name=Pattern.compile("[A-Za-z]{8}");
	
        boolean checkUsername(String user)
        {    Matcher matches=name.matcher(user);
        	if(matches.matches())
        		return true;
        	else
			return false;
        	
        }
	public static void main(String[] args) {
		boolean result=false;
		System.out.println("Enter the Username and it should end with '_job'");
		Scanner scanner=new Scanner(System.in);
		String username=scanner.nextLine();
		JobSeeker js=new JobSeeker();
		
		if(username.contains("_job")) 
		    result =js.checkUsername(username.substring(0, username.length()-4));
		else
		   	 System.err.println("Please enter username with _job");
		
		if(result)
			System.out.println("Username Validated !!!");
		else
			System.out.println("Username not validated.!!");
			
		}
				
	}


