package Lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
/*
 * Exercise 3: Write a Java program that displays the number of characters, lines and words in a text?
 */
public class NumberOf {

	public static void main(String[] args) {
		FileInputStream fin=null;
		FileOutputStream fout=null;
		int i=0;
		int line=0,word=0,characters=0;
		
		try {
			fin=new FileInputStream("src/Lab8/StringTokenizerDemo.java");
			fout=new FileOutputStream("src/Lab8/NewFile.doc");
						
			while(i!=-1)
			{
					
			     	
				i=fin.read();
				fout.write(i);
				char element=(char)i;
				
				if(element=='\n')
					line++;
				else if(element==' ')
					word++;
				characters++;
					
				}
			System.out.println("The File contains ");
			System.out.println(line+" Lines, \n"+word+" Word,\n"+ characters+" Characters.");
				
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
