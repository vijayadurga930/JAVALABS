package Lab2;

public class MediaItem extends Item {
	private int randomNumber=1234;
	
	public MediaItem() {
	   System.out.println("The private data inside MediaItem is "+randomNumber);
	}

	@Override
	public void checkIn(int id) {
		System.out.println("Candidate "+id+" checked in");		
	}

	@Override
	public void checkOut(int id) {
		System.out.println("Candidate "+id+" checked out.>!!!");
		
		
		
	}

}

class Video extends MediaItem
{
	private String director;
	private String genre;
	private int year;
	
	public Video(String director, String genre, int year) {
		super();
		this.director = director;
		this.genre = genre;
		this.year = year;
		System.out.println("Inside Media Item" );
		
	}
	
	public void printDetails()
	{
		System.out.println("Director :"+director+" Genre : "+genre + "Year :" +year);
	}
	
	
	
	
}

class CD extends MediaItem{
	private String artist;
	private String genre;
	
	public CD(String artist, String genre) {
		super();
		this.artist = artist;
		this.genre = genre;
	}
	public void printDetails()
	{
		System.out.println("Artist :"+artist +" Genre : "+genre);
	}
	
	
	
	
}


