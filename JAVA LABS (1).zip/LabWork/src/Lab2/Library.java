package Lab2;
/*
 * Using an inheritance hierarchy, design a Java program to model items at 
 * a library (books, journal articles, videos and CDs.) Have an abstract 
 * superclass called Item and include common information that the library 
 * must have for every item (such as unique identification number, title, and number of copies). 
 * No actual objects of type Item will be created - each actual item will be an object of a (non-abstract) subclass. 
 * Place item-type-specific behavior in subclasses (such as a video's year of release, a CD's musical genre, or a book's author).
 */
import java.util.Scanner;

public class Library extends  Item{

	public static void main(String[] args) {
		
		System.out.println("Inside Library");
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Member id");
		int id=scanner.nextInt();
		
		System.out.println("Enter year of book published");
		int year=scanner.nextInt();
		

		System.out.println("Enter Author");
		String author=scanner.next();
		
		System.out.println("Enter Genre");
		String genre=scanner.next();
		
		System.out.println("Enter Director");
		String director=scanner.next();

		System.out.println("Enter Arist name");
		String artist=scanner.next();
		
		
		Item obj=new Library();
		obj.checkIn(id);
		obj.checkIn(id);
		
		Video obj1=new Video(director,genre,year);
		obj1.printDetails();
		
		CD obj2=new CD(artist,genre);
		obj2.printDetails();
		
		JournalPaper obj3=new JournalPaper(author);
		obj3.printyear(year);
		
		obj3.checkIn(id);
		obj3.checkOut(id);
		
		
		
	}

	@Override
	public void checkIn(int id) {
		System.out.println("The member with id "+id+ "check in");
		
	}

	@Override
	public void checkOut(int id) {
		System.out.println("The member with id "+id+ "check out..$#^");
		
	}

}
