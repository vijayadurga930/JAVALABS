package June29;

import java.util.Scanner;



public class SubsequentNumber {
	int checkNumber(int number) {
		//For changing the number
		int rem,result,rev=0,reverse=0;
		int copy=number;
		
		
		while (number > 0) {
			rem = number % 10;
			if(rem==9)
				rem=0;
			else
		    rem=rem+1;
			
			rev=rev*10+rem;
			number = number / 10;
		}
		
	
			while (rev > 0) {
				rem = rev % 10;
				reverse = reverse * 10 + rem;
				rev = rev / 10;

			}
			

	
	

	return reverse;
}

	public static void main(String args[]) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter  number");
		int no = scanner.nextInt();

		SubsequentNumber obj = new SubsequentNumber();
		int arr = obj.checkNumber(no);
		System.out.println("Number is :"+arr);

	}		


}
