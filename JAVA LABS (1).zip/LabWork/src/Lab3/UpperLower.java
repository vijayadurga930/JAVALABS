package Lab3;
/*
 * Exercise 2: Create a method that can accept an array of String objects and 
 * sort in alphabetical order. The elements in the left half should be completely in uppercase and the elements 
 * in the right half should be completely in lower case. Return the resulting array.
 */
import java.util.Arrays;
import java.util.Scanner;

public class UpperLower {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter total number");
		int no = scanner.nextInt();
		
		String[] array=new String[no];
		System.out.println("Enter "+no+" Names :");
	   
					scanner.nextLine();
		for (int i=0; i<no; i++)
				 array[i] = scanner.nextLine(); 
		  
		
		 convert(array);
				
	}

	private static void convert(String[] sortedArray) {
		Arrays.sort(sortedArray);
		
		int len;
		
		for(int i=0;i<sortedArray.length;i++)
		{
			len=sortedArray[i].length();					
			
			if(len%2==0)
			{
				    String a =sortedArray[i].substring(0, len/2).toUpperCase();
					String b =sortedArray[i].substring((len/2),len).toLowerCase();
					sortedArray[i]=a+b;
					System.out.println(sortedArray[i]);
			}
			else if(len%2!=0)
			{
				String a=sortedArray[i].substring(0, (len/2)+1).toUpperCase();
				String b=sortedArray[i].substring((len/2)+1,len).toLowerCase();
				sortedArray[i]=a+b;
				System.out.println(sortedArray[i]);
			}
			
		}
		    
 }

	private static String[] sorting(String[] array) {
		
		
			
		
	return array;
	}

}
