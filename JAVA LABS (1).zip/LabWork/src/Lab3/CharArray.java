package Lab3;
/*
 * Exercise 4: Create a method that accepts a character 
 * array and count the number of times each character is present in the array.
 */
import java.util.Scanner;

import June28.ReverseNumber;

public class CharArray {
	
	void countChar(String arr) {
		int count;int find=1;
	
		for (int i = 0; i < arr.length(); i++)
		{  
			
		   for(int k=i-1;k>=0;k--)
		   {
			   if(arr.charAt(k)==arr.charAt(i))
			     {
				   find=0;
				   	break;
				   	}
			   
			   else    
		         find=1;
		   }
			  if(find==1) 
		    {	count=0;
			for(int j=i;j<arr.length();j++)
			{	
				if(arr.charAt(i) == arr.charAt(j))
					count++;
			}			
              		
			  System.out.println(arr.charAt(i)+ " : "+count);
		   }}
		}
		
		
		

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Characters");		
		String array;
		
		 array = scanner.nextLine(); 
		
		CharArray obj = new CharArray();
		 obj.countChar(array);

	}

}
