package Lab3;
/*
 * Exercise 1: Create a method which accepts 
 * an array of integer elements and return the second smallest element in the array
 */
import java.util.Scanner;

public class SecondSmallest {
	  //Method to get the 2nd smallest element in the Array
	   int[] getSecondSmallest(int array[])
	   {    int temp=0;
	   
		   for(int i=0;i<array.length;i++)
		   {
			   for(int j=i+1;j<array.length;j++) {
				    if(array[i]>array[j]) {
				    	temp=array[i];
				    	array[i]=array[j];
				    	array[j]=temp;
				 			 
				    }
			   }
			   
		   }	
		   
		   
		   return array;
		   
	   }
	 public static void main(String args[])
	 {
		 
		 Scanner scanner=new Scanner(System.in);
		 System.out.println("Enter total number");
		 int no=scanner.nextInt();
		 int array[]=new int[no];
		 System.out.println("Enter "+no+ "Numbers");
		 for(int i=0;i<no;i++)
			 array[i]=scanner.nextInt();
		 
		 
		 SecondSmallest obj=new SecondSmallest();
		 int arr[]=obj.getSecondSmallest(array);
		 System.out.println(arr[1]);
		 
	 }

}
