package Lab3;
/*
 * Exercise 3: Create a method which accepts an integer array, 
 * reverse the numbers in the array and returns the resulting array in sorted order
 */
import java.util.Scanner;

public class SortedReverse {

	int[] reverseArray(int array[]) {
		int number;
		int rem;
		for (int i = 0; i < array.length; i++) {
			number = array[i];
			int reverse = 0;
			while (number > 0) {
				rem = number % 10;
				reverse = reverse * 10 + rem;
				number = number / 10;

			}
			array[i] = reverse;

		}
		for (int i = 0; i < array.length-1; i++) 
		{		int temp=0;
			if(array[i+1]<array[i]) {
				temp = array[i];
				array[i]=array[i+1];
				array[i+1]=temp;
			}
		}
		return array;

	}

	public static void main(String args[]) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter total number");
		int no = scanner.nextInt();

		int array[] = new int[no];

		System.out.println("Enter " + no + " Numbers");

		for (int i = 0; i < no; i++)
			array[i] = scanner.nextInt();

		 SortedReverse obj = new SortedReverse();
		int arr[] = obj.reverseArray(array);
		System.out.println("number in Sorted Reverse are : ");

		for (int i = 0; i < no; i++)
			System.out.println(arr[i]);

	}

}
