package Lab4;
/*
 * Exercise 1: Create a method to find the sum of 
 * the cubes of the digits of an n digit number
 */
import java.util.Scanner;
import java.util.zip.Checksum;

public class Operators {
	
		int checkSum(int number) {
			//For checking the  number
		int rem;
		int result=0;
		
		   while (number > 0) {
				rem = number % 10;
				result = result+(rem*rem*rem);
				number = number / 10;
			}
		

		return result;
	}

		public static void main(String args[]) {

			Scanner scanner = new Scanner(System.in);

			System.out.println("Enter Number");
				int num= scanner.nextInt();

			Operators obj = new Operators();
			int number = obj.checkSum(num);
			System.out.println("Sum of Cube is :"+number);

				
		}


}
