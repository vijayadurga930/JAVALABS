package Lab1;
/*
 * Exercise 3: Create a method to check if a number is an increasing number
Method
 */
import java.util.Scanner;

public class IncreasingNumber {
	boolean checkNumber(int num) {
	// for Checking the number

		int n=num;
		int no=0,f1,f2,temp;
		int c=1;

		f2=n%10;
		n=n/10;
	
		while(n>0) 
		{
			f1=n%10;
			n=n/10;
		
			if(f2<f1) // Camparing the two numbers
				c=0;
			
			f2=f1;
			
		}
		if(c==0)
		return false;
		
		else
	    return true;
		
	}
	
	
	
	public static void main(String args[]) {
		int num;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a number to Check");
		num=scanner.nextInt();
		IncreasingNumber IN=new IncreasingNumber();
		
		boolean result=IN.checkNumber(num);
		if(result)
			System.out.println("Number is a Increasing Number");
		else
			System.out.println("Number is not increasing number");
		
	}

}
