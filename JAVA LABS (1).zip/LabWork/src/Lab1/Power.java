package Lab1;
/*
 * Exercise 4: Create a method to check if a number is a power of two or not
Method
 */
import java.util.Scanner;

public class Power {
	
	boolean checkNumber(int num)
	{
		int c=0;
		int n=num;
		
	     while(num!=1) {
	    	 if(num%2 != 0)
	    		 return false;
	         num=num/2;
	         c++;
	     }
	     System.out.println( n +" is : 2 power "+c);
	     return true;	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number Power of 2");
		number=sc.nextInt();
		Power obj=new Power();
		boolean result=obj.checkNumber(number);
		
		if(result)
			System.out.println("Number is Power of 2");
		else
			System.out.println("Number is not a power of 2");

	}

}
