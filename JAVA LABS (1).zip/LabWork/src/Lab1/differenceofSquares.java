package Lab1;
/*
 * Exercise 2: Create a class with a method to find the difference 
 * between the sum of the squares and the square of the sum of the first n natural numbers.*
 */
import java.util.Scanner;

public class differenceofSquares {
	int calculateDifference(int n) {
		int sum=0,square=0,diff;
		
		for(int i=1;i<=n;i++)
			sum=sum+(i*i);
		
		for(int i=1;i<=n;i++)
			square=square+i;

		square=square*square;
		diff=sum-square;
		
		return diff;
	}
	
	public static void main(String args[]) {
		int num;
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Please enter a number");
		num=scanner.nextInt();
		
		differenceofSquares dos=new differenceofSquares();
		int result =dos.calculateDifference(num);
		
		System.out.println("Differnce of (Sum of SQUARES ) & (SQUARES of Sum) is :"+result);
	}

}
