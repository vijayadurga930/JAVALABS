package Lab9;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
/*
 * Exercise 3: Create a method which accepts an 
 * array of numbers and returns the numbers and their squares in HashMap
 */
public class HashMapSorted {

  	public static HashMap<String,Integer> getValues(HashMap<String, Integer> hm)
		{
			List<Map.Entry<String,Integer>> list=new LinkedList<Map.Entry<String,Integer>>(hm.entrySet());
			
			Collections.sort(list,new Comparator<Map.Entry<String,Integer>>() {
				public int compare(Map.Entry<String,Integer> o1,Map.Entry<String,Integer> o2)
				{
					return (o1.getValue()).compareTo(o2.getValue());
				}
			});
			HashMap<String,Integer> map=new LinkedHashMap<String,Integer>();
			for(Map.Entry<String, Integer> aa:list)
			{
				map.put(aa.getKey(),aa.getValue());
			}
			return map;
		}
  	public static void main(String[] args) {
  		HashMap<String,Integer> hm=new HashMap<>();
  		 hm.put("C", 91); 
         hm.put("Data Structure", 85); 
         hm.put("Database", 91); 
         hm.put("Java", 95); 
         hm.put("C++", 79); 
         hm.put("Python", 80); 
         
         Map<String,Integer> map=getValues(hm);
         
         for (Map.Entry<String, Integer> entry : map.entrySet())
         {
        	 System.out.println("Key :"+entry.getKey()+ "Values :"+entry.getValue());
         }

	}

}
