package Lab9;
/*
 * Exercise 2: Create a method that accepts a character array and count the number of times each character is present in the array. Add how many 
 * times each character is present to a hash map with the character as key and the repetitions count as value
 */
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import Lab3.CharArray;

public class CountChar {

	void countChar(String arr) {
		int count;int find=1;
		HashMap<Character,Integer> hm=new HashMap<>();
		
		for (int i = 0; i < arr.length(); i++)
		{  
			
		   for(int k=i-1;k>=0;k--)
		   {
			   if(arr.charAt(k)==arr.charAt(i))
			     {
				   find=0;
				   	break;
				   	}
			   
			   else    
		         find=1;
		   }
			  if(find==1) 
		    {	count=0;
			for(int j=i;j<arr.length();j++)
			{	
				if(arr.charAt(i) == arr.charAt(j))
					count++;
			}			
              		hm.put(arr.charAt(i),count);
              		
			  System.out.println(arr.charAt(i)+ " : "+count);
		   }}
		for(Map.Entry<Character,Integer> map:hm.entrySet()) {
			System.out.println("Key :"+map.getKey()+ "  Values :"+map.getValue());
		}
		}
		
		
		

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Characters");		
		String array;
		
		 array = scanner.nextLine(); 
		
		CountChar obj = new CountChar();
		 obj.countChar(array);

	}
}
