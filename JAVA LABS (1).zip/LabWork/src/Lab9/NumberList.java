package Lab9;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
/*
 * Exercise 3: Create a method which 
 * accepts an array of numbers and returns the numbers and their squares in HashMap
 */
public class NumberList {

	public static void main(String[] args) {

		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter number of Numbers");
		int number=scanner.nextInt();
		int a[]=new int[number];
		System.out.println("Enter " +number+" Numbers:");
        
		for(int i=0;i<number;i++)
			a[i]=scanner.nextInt();
		
		NumberList nl=new NumberList();
		HashMap<Integer,Integer> hm=new HashMap<>();
		
		hm=nl.getSquares(a);
		
		for(Entry<Integer, Integer> map: hm.entrySet())
		{
			System.out.println("Key :"+map.getKey()+" Value:"+map.getValue());
		}
		
		
	}

	private HashMap<Integer,Integer> getSquares(int[] a) {
		HashMap<Integer,Integer> hm=new HashMap<>();
		
		for(int i=0;i<a.length;i++)
			hm.put(a[i], a[i]*a[i]);
				
		return hm;
		
		
	}

}
