package Lab11;

/*
 * Exercise 1: Implement the Multithreading Assignments using Executor, ExecutorService interface .
 */

public class FileProgramExecutor {

	public static void main(String[] args) {
		String source = "C:\\AmberSpace\\LabWork\\Sample.txt";
		String target = "C:\\AmberSpace\\LabWork\\Sample3.txt";
		CopyDataThreadExecutor copy = new CopyDataThreadExecutor(source, target);
		copy.runnable1();

	}

}
