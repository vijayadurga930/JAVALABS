package com.capgemini.fms.dao;

import java.util.HashMap;

import com.capgemini.fms.exception.FMSException;

public interface IFeedbackDAO {
	
	public void addFeedbackDetails(String name, int rating, String subject) throws FMSException;
	
	public HashMap<String, Integer> getFeedbackReport() throws FMSException;
}
