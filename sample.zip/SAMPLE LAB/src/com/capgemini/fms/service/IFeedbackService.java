package com.capgemini.fms.service;

import java.util.HashMap;

import com.capgemini.fms.exception.FMSException;

public interface IFeedbackService {
	
    public void addFeedbackDetails(String name, int rating, String subject) throws FMSException;
	
	public HashMap<String, Integer> getFeedbackReport() throws FMSException;
	
	void validateName(String teacherName) throws FMSException;
	
	void validateRating(int rating) throws FMSException;
	
	void validateSubject(String topic) throws FMSException;
}
