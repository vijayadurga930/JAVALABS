package com.capgemini.fms.ui;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.dao.IFeedbackDAO;
import com.capgemini.fms.exception.FMSException;
import com.capgemini.fms.service.FeedbackService;
import com.capgemini.fms.service.IFeedbackService;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		Scanner scanner = null;

		IFeedbackService service = new FeedbackService();

		String continueChoice = "";
		boolean continueValue = false;

		do {
			System.out.println("****** Feedback Application ******");
			System.out.println("1. Add Feedback");
			System.out.println("2. Print Feedback Report");
			System.out.println("3. Exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					
					switch (choice) {

					case 1:

						String teacherName = "";
						boolean teacherNameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter teacher name");
							try {
								teacherName = scanner.nextLine();
								service.validateName(teacherName);
								teacherNameFlag = true;
								break;
							} catch (FMSException e) {
								teacherNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!teacherNameFlag);

						String topic = "";
						boolean topicFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter subject:");
							try {
								topic = scanner.nextLine();
								service.validateSubject(topic);
								topicFlag = true;
								break;
							} catch (FMSException e) {
								topicFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!topicFlag);
						
						int rating = 0;
						boolean ratingFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter rating: ");
							try {
								rating = scanner.nextInt();
								service.validateRating(rating);
								ratingFlag = true;
								break;
							} catch (FMSException e) {
								ratingFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!ratingFlag);

						//Feedback feedback= new Feedback(teacherName, rating, topic);
						try {
							service.addFeedbackDetails(teacherName, rating, topic);
						} catch (FMSException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						break;

					case 2:
						try {
							Map<String, Integer> feedbackrep = service.getFeedbackReport();
							System.out.println(feedbackrep);
							}catch (FMSException e) {
							System.err.println(e.getMessage());
						}
						break;
						
					case 3:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;
					
					
					default:
						choiceFlag = false;
						System.out.println("input should be 1, 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);
		} while (continueValue);
		scanner.close();
	}

	
}
