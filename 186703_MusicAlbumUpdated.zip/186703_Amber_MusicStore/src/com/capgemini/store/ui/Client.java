package com.capgemini.store.ui;

import java.util.Scanner;

import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.InvalidAlbumIdException;
import com.capgemini.store.service.AlbumService;
import com.capgemini.store.service.AlbumServiceImpl;

/**
 * 
 * @author ambpraka
 * @version 1 Class Client to accept the data from user and show to console
 */
public class Client {

	AlbumService service = new AlbumServiceImpl();
	static Scanner scanner = null;
	static String choice, title, artist;
	static double price, rating;
	static boolean bool;
	boolean status;
	boolean Flag;

	/**
	 * 
	 * @param args
	 *            main() for accepting the input and displaying the output
	 */
	public static void main(String[] args) {
		/*
		 * Showing the main menu in console
		 */
		do {
			System.out.println("Main Menu");
			System.out.println(" 1- Add Music Album \n 2- Find Album By Id \n 3-Exit");
			scanner = new Scanner(System.in);
			int option = scanner.nextInt();
			Client client = new Client();
			switch (option) {
			case 1:
				client.AddMusicAlbum();
				break;
			case 2:
				client.findAlbum();
				break;
			case 3:
				System.out.println("Thank You ! Visit Again !!");
				System.exit(0);
			}
			

			/*
			 * Checking the yes or no option of user.
			 */
			do {
				System.out.println("\n Do you wish to Continue ? (Y= yes/N= no)");
				scanner = new Scanner(System.in);
				choice = scanner.nextLine();

				if (choice.equalsIgnoreCase("y") || choice.equalsIgnoreCase("n"))
					bool = false;
				else {
					System.err.println("Invalid Input!! Enter Y or N");
					bool = true;
				}
			} while (bool);
		} while (choice.equalsIgnoreCase("Y"));

	}
	/*
	 * findAlbum() to find the album by the entered Id
	 */

	private void findAlbum() {
		scanner = new Scanner(System.in);
		System.out.println("Enter Album Id :");
		int id2 = scanner.nextInt();
		Album album;
		try {
			album = service.findById(id2);
			System.out.println(album);
		} catch (InvalidAlbumIdException e) {

			System.err.println("Problem Occured");
		}

	}

	/**
	 * AddMusicAlbum() to save the album details
	 */
	private void AddMusicAlbum() {
		scanner = new Scanner(System.in);
		/**
		 * Album title is accepted and validated.
		 */
		do {
			System.out.println("Enter Title :");
			title = scanner.nextLine();

			try {
				Flag = false;
				status = service.isTitleArtistvalid(title);
				if (!status) {
					Flag = true;
					throw new InvalidAlbumIdException("Invalid Title Entered! ! First Letter must be Capital !!");

				}
			} catch (InvalidAlbumIdException e) {
				System.err.println(e.getMessage());
			}
		} while (Flag);

		/**
		 * Album artist is accepted and validated.
		 */
		do {
			System.out.println("Enter Artist :");
			artist = scanner.nextLine();
			try {
				Flag = false;
				status = service.isTitleArtistvalid(artist);
				if (!status) {
					Flag = true;
					throw new InvalidAlbumIdException("Invalid Artist Entered! First Letter must be Capital !!");

				}
			} catch (InvalidAlbumIdException e) {
				System.err.println(e.getMessage());
			}
		} while (Flag);

		/**
		 * Album price is accepted and validated.
		 */
		
		do {
			System.out.println("Enter Price :");
			price = scanner.nextDouble();
			try {
				Flag = false;
				status = service.isPricevalid(price);
				if (!status) {
					Flag = true;
					throw new InvalidAlbumIdException("Invalid Price !!");

				}
			} catch (InvalidAlbumIdException e) {
				System.err.println(e.getMessage());
			}
		} while (Flag);

		/**
		 * Album rating is accepted and validated.
		 */
		
		do {
			System.out.println("Enter Rating :");
			rating = scanner.nextDouble();
			try {
				Flag = false;
				status = service.isRatingValid(rating);
				if (!status) {
					Flag = true;
					throw new InvalidAlbumIdException("Invalid Rating (1-10)!!");

				}
			} catch (InvalidAlbumIdException e) {
				System.err.println(e.getMessage());
			}
		} while (Flag);

		Album album = new Album(title, artist, price, rating);
		
		/**
		 * Printing the album id after saving.
		 */
		int id = service.saveAlbum(album);
		System.out.println("Album stored with Id :" + id);

	}

}
