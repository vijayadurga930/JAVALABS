package com.capgemini.store.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.store.bean.Album;
import com.capgemini.store.dao.AlbumDao;
import com.capgemini.store.dao.AlbumDaoImpl;
import com.capgemini.store.exception.InvalidAlbumIdException;

/*
 * To implement album service and  to write the business logic in it.
 */
public class AlbumServiceImpl implements AlbumService {
	AlbumDao dao = new AlbumDaoImpl();

	@Override
	public int saveAlbum(Album album) {
		int id = dao.generateId();
		boolean status = dao.persist(album);
		if (status)
			return id;
		return 0;
	}

	@Override
	public Album findById(int id) throws InvalidAlbumIdException {
		Album album = dao.find(id);
		return album;
	}

	@Override
	public boolean isPricevalid(double price) throws InvalidAlbumIdException {

		if (price > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean isTitleArtistvalid(String name) throws InvalidAlbumIdException {
		Pattern nameptn = Pattern.compile("^[A-Z]{1,}[a-z]{4,}$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean isRatingValid(double rating) throws InvalidAlbumIdException {
		if (rating > 0 && rating <= 10)
			return true;
		else
			return false;
	}

}
