package com.capgemini.store.service;

import com.capgemini.store.bean.Album;
import com.capgemini.store.exception.InvalidAlbumIdException;
/*
 * AlbumService Interface
 */
public interface AlbumService {
	int saveAlbum(Album album);
	Album findById(int id)throws InvalidAlbumIdException;
	boolean isRatingValid(double rating) throws InvalidAlbumIdException;
	boolean isTitleArtistvalid(String name) throws InvalidAlbumIdException;
	boolean isPricevalid(double rating) throws InvalidAlbumIdException;
	
}
