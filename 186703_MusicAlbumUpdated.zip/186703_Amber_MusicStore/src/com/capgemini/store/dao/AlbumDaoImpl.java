package com.capgemini.store.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.store.bean.Album;
/**
 * Dao logic where data is stored in HashMap albums and implements AlbumDao interface
 */
public class AlbumDaoImpl implements AlbumDao {
	private static Map<Integer, Album> albums = new HashMap<Integer, Album>();
	int id;

	public int generateId() {
		id = (int) (Math.random() * 100);

		return id;

	}

	@Override
	public boolean persist(Album album) {

		Album status = albums.put(id, album);

		if (status == null)
			return true;
		return false;
	}

	@Override
	public Album find(int ID) {
		int albumId = new Integer(ID);
		Iterator<Integer> iterator = albums.keySet().iterator();

		Album album;
		while (iterator.hasNext()) {

			int newid = new Integer(iterator.next());
			if (newid == albumId) {
				album = albums.get(albumId);
				return album;
			}

		}
		return null;

	}
}
