package com.capgemini.store.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.store.bean.Album;
/*
 * AlbumDaO Interface
 */
public interface AlbumDao {
	Map<Integer, Album> albums= new HashMap<>();
	boolean persist(Album album);
	Album find(int id);
	public int generateId();
}
