package com.capgemini.store.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.store.bean.Album;
import com.capgemini.store.dao.AlbumDao;
import com.capgemini.store.dao.AlbumDaoImpl;

public class TestCase {
	AlbumDao dao=new AlbumDaoImpl();
	Album album=new Album("Amber","AmberRai",1000,12);
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testpersist1() {
		boolean status=dao.persist(album);
		assertTrue(status);
		assertNotEquals(status, false);
		
	}
	@Test
	public void testfind() {
		Album status=dao.find(10);

		assertNotEquals(status, false);
		assertNull(status);
	}
	

}
