package java.com.capgemini.service;

import java.util.List;

import java.com.capgemini.bean.Customer;
import java.com.capgemini.dao.CustomerDao;
import java.com.capgemini.dao.CustomerDaoImpl;

public class ServiceLayerImpl implements ServiceLayer {
CustomerDao customerdao=new CustomerDaoImpl();
boolean status=false;
int row=-1;
	@Override
	public int saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		row=customerdao.insertCustomer(customer);
		return row;
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		row=customerdao.updateCustomer(customer);
		if(row>0)
			status=true;
		else
			status=false;
			return status;
	}

	@Override
	public boolean removeCustomer(int custId) {
		// TODO Auto-generated method stub
		row=customerdao.deleteCustomer(custId);
		if(row>0)
			status=true;
		else
			status=false;
			return status;
	}

	@Override
	public Customer viewById(int custId) {
		// TODO Auto-generated method stub
		return customerdao.getById(custId);
	}

	@Override
	public List<Customer> viewAll() {
		// TODO Auto-generated method stub
		return customerdao.viewAll();
	}

}
