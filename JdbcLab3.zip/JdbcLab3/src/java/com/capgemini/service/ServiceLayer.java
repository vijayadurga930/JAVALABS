package java.com.capgemini.service;

import java.util.List;

import java.com.capgemini.bean.Customer;

public interface ServiceLayer {
int saveCustomer(Customer customer);
boolean updateCustomer(Customer customer);
boolean removeCustomer(int custId);
Customer viewById(int custId);
List<Customer> viewAll();

}
