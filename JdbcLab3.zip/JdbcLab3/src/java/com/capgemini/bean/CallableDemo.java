package java.com.capgemini.bean;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

import java.com.capgemini.jdbc.utility.Dbconnection;

public class CallableDemo {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter empno to view");
		int empno=scanner.nextInt();
		
		try(Connection connection=Dbconnection.getConnection();) {
			CallableStatement statement=connection.prepareCall("{call empdata(?,?,?)}");
			statement.setInt(1, empno);
			statement.registerOutParameter(2, Types.VARCHAR);
			statement.registerOutParameter(3, Types.NUMERIC);
			statement.execute();
			String name=statement.getString(2);
			int salary=statement.getInt(3);
			System.out.println("name is :"+name+" "+" salary is :" +" "+salary);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
