package java.com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import java.com.capgemini.bean.Customer;
import java.com.capgemini.jdbc.utility.Dbconnection;

public class CustomerDaoImpl implements CustomerDao {

	PreparedStatement statement = null;
	ResultSet resultSet = null;
	int row = -1;

	public int insertCustomer(Customer customer) {
		int custId = 0;
		try (Connection connection = Dbconnection.getConnection();) {

			statement = connection.prepareStatement("select customerseq.NEXTVAL from dual");
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				custId = resultSet.getInt(1);
				statement = connection.prepareStatement("insert into customer values(?,?,?,?,?)");
				statement.setInt(1, custId);
				statement.setString(2, customer.getName());
				statement.setString(3, customer.getAddress());
				Date sqldob = new Date(customer.getDob().getTime());
				statement.setDate(4, sqldob);
				statement.setLong(5, customer.getPhone());
				row = statement.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return custId;
	}

	public int updateCustomer(Customer customer) {
		try (Connection connection = Dbconnection.getConnection();) {

			statement = connection
					.prepareStatement("update customer set name=?,address=?,dob=?,phone=? where custid=?");


			statement.setString(1, customer.getName());
			statement.setString(2, customer.getAddress());
			Date sqldob = new Date(customer.getDob().getTime());
			statement.setDate(3, sqldob);
			statement.setLong(4, customer.getPhone());
			statement.setInt(5, customer.getCustId());
			
			row = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return row;
	}

	public int deleteCustomer(int custId) {
		try (Connection connection = Dbconnection.getConnection();) {

			statement = connection.prepareStatement("delete from customer where custid=?");

			statement.setInt(1, custId);
			row = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return row;
	}

	public Customer getById(int custId) {
		Customer customer = new Customer();
		try (Connection connection = Dbconnection.getConnection();) {

			statement = connection.prepareStatement("select*from customer where custid=?");
			;
			statement.setInt(1, custId);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {

				customer.setCustId(resultSet.getInt("custId"));
				customer.setName(resultSet.getString("name"));
				customer.setAddress(resultSet.getString("address"));
				customer.setDob(resultSet.getDate("dob"));
				customer.setPhone(resultSet.getLong("phone"));
			}

		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return customer;

	}

	public List<Customer> viewAll() {
		// TODO Auto-generated method stub
		List<Customer> list1 = new ArrayList<>();
		Customer customer = new Customer();
		try (Connection connection = Dbconnection.getConnection();) {

			statement = connection.prepareStatement("select*from customer ");
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				customer.setCustId(resultSet.getInt("custId"));
				customer.setName(resultSet.getString("name"));
				customer.setAddress(resultSet.getString("address"));
				customer.setDob(resultSet.getDate("dob"));
				customer.setPhone(resultSet.getLong("phone"));
				list1.add(customer);
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return list1;

	}

}
