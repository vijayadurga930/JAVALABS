package java.com.capgemini.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import java.com.capgemini.bean.Customer;
import java.com.capgemini.service.ServiceLayer;
import java.com.capgemini.service.ServiceLayerImpl;

public class MainUiClass {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ServiceLayer service = new ServiceLayerImpl();
		while (true) {
			System.out.println("1.insert\n 2.update\n 3.delete\n 4.viewbyid\n 5.viewall");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
			{
				try {System.out.println("inserting elements in to the database");
				String name=scanner.next();
				String address=scanner.next();
				long phone=scanner.nextLong();
				System.out.println("enetered the dob format should be like dd-MM-yy");
				String dob=scanner.next();
				SimpleDateFormat sf=new SimpleDateFormat("dd-MM-yy");
				Date d=sf.parse(dob);
				Customer customer=new Customer(0, name, address,  d, phone);
				int custId=service.saveCustomer(customer);
				if(custId>0)
				{
					System.out.println("customer registered successfully and your id is"+custId);
				}
				else
					System.out.println("not registered");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				}

				break;
			case 2:{
			     System.out.println("updating elements in to the database");
			     System.out.println("enter the id to be updated");
			     int id=scanner.nextInt();
				
				String name=scanner.next();
				String address=scanner.next();
				System.out.println("enetered the dob format should be like dd-MM-yy");
				String dob=scanner.next();
				long phone=scanner.nextLong();
				
				SimpleDateFormat sf=new SimpleDateFormat("dd-MM-yy");
				Date d;
				
				try {
					d = sf.parse(dob);
					Customer customer=new Customer(id, name, address,  d, phone);
					boolean status=service.updateCustomer(customer);
					if(status)
					System.out.println("information updated succesfully");
					else
						System.out.println("not updated");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				}
				

				break;
			case 3:
			{
				System.out.println("enter the id to be deleted");
				int id=scanner.nextInt();
			boolean status=	service.removeCustomer(id);
			if(status)
				System.out.println("information deleted succesfully");
				else
					System.out.println("not deletd");
			}

				break;
			case 4:
			{
				System.out.println("enter the id to be viewed");
				int id=scanner.nextInt();
				Customer customer=service.viewById(id);
				if(customer!=null)
				System.out.println(customer);
				else
					System.out.println("there is no customer with the given id");
			}
				break;
			case 5:
			{
List<Customer> list11=new ArrayList<>();
list11=service.viewAll();
System.out.println(list11);
			}
				break;
			default:
			{
				System.out.println("system will get exited");
				System.exit(0);
			}
			}
		}

	}

}
